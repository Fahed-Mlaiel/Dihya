"""
Initialisation des modèles de données pour l'application Dihya Coding.
Ce module importe tous les modèles nécessaires à l'ORM et à l'application.
"""

from .user import User

# Ajouter ici d'autres modèles si besoin (ex : Project, Role, etc.)
```# filepath: /workspaces/Dihya/Dihya/backend/flask/app/models/__init__.py
"""
Initialisation des modèles de données pour l'application Dihya Coding.
Ce module importe tous les modèles nécessaires à l'ORM et à l'application.
"""

from .user import User

# Ajouter ici d'autres modèles si besoin (ex : Project, Role, etc.)