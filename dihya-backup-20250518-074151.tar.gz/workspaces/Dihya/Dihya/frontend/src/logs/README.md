# 🗒️ Logs – Dihya Coding

Ce dossier centralise tous les fichiers de logs générés par Dihya Coding pour la génération de projets, modules, opérations critiques et auditabilité.  
Chaque log vise : traçabilité, sécurité, conformité RGPD, auditabilité, extensibilité, robustesse et documentation claire.

---

## 🚀 Objectifs

- Garantir la traçabilité et l’auditabilité de toutes les opérations sensibles (génération, sauvegarde, restauration…)
- Assurer la conformité RGPD : anonymisation, consentement, droit à l’oubli, documentation claire
- Faciliter l’analyse, la maintenance et l’extension des stratégies de logs

---

## 📁 Structure recommandée

- `generation.log` : Journal des générations de projets et modules (anonymisé, RGPD)
- `security.log` : Journal des événements de sécurité (accès, refus, alertes)
- `audit.log` : Journal d’audit global (opérations critiques, conformité)
- `README.md` : Présentation, bonnes pratiques, exemples

---

## 🛡️ Bonnes pratiques

- **Sécurité & RGPD** : Pas de données personnelles, logs anonymisés, consentement utilisateur requis, droit à l’oubli (purge).
- **Auditabilité** : Historique local des opérations, logs effaçables, documentation claire.
- **Extensibilité** : Ajout facile de nouveaux types de logs ou stratégies d’audit.
- **Robustesse** : Gestion des erreurs de log, validation des entrées.
- **Documentation** : Format de log documenté, exemples d’utilisation, conventions claires.

---

## 📝 Exemple de format de log

```
[timestamp] [action] [status] [project/module] [détails anonymisés]
2025-05-17T08:00:00.000Z GENERATE_PROJECT SUCCESS proj_***_23a4 modules=[ai,seo] user=[anonymized]
```

---

## 📚 Documentation associée

- [generation.log](./generation.log)
- [Sécurité & RGPD](../docs/security.md)
- [Utils](../utils/README.md)
- [Cahier des charges Dihya Coding](../../../docs/user_guide/README.md)

---

> **Dihya Coding : logs modernes, sécurisés, robustes, extensibles et conformes RGPD pour chaque génération.**