"""
Initialisation des schémas de validation pour l'application Dihya Coding.
Ce module peut contenir les imports de schémas Marshmallow ou Pydantic pour la validation des données.
À compléter selon les besoins du projet (UserSchema, ProjectSchema, etc.).
"""

# Exemple d'import (à créer dans ce dossier si besoin) :
# from .user_schema import UserSchema
```# filepath: /workspaces/Dihya/Dihya/backend/flask/app/schemas/__init__.py
"""
Initialisation des schémas de validation pour l'application Dihya Coding.
Ce module peut contenir les imports de schémas Marshmallow ou Pydantic pour la validation des données.
À compléter selon les besoins du projet (UserSchema, ProjectSchema, etc.).
"""

# Exemple d'import (à créer dans ce dossier si besoin) :
# from .user_schema import UserSchema